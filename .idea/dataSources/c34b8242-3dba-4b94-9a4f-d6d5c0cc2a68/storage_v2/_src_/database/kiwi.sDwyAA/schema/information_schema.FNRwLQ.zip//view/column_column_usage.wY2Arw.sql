CREATE VIEW column_column_usage (table_catalog, table_schema, table_name, column_name, dependent_column) AS
SELECT DISTINCT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS table_catalog,
                n.nspname::information_schema.SQL_IDENTIFIER          AS table_schema,
                c.relname::information_schema.SQL_IDENTIFIER          AS table_name,
                ac.attname::information_schema.SQL_IDENTIFIER         AS column_name,
                ad.attname::information_schema.SQL_IDENTIFIER         AS dependent_column
FROM pg_namespace n,
     pg_class c,
     pg_depend d,
     pg_attribute ac,
     pg_attribute ad,
     pg_attrdef atd
WHERE n.oid = c.relnamespace
  AND c.oid = ac.attrelid
  AND c.oid = ad.attrelid
  AND ac.attnum <> ad.attnum
  AND ad.attrelid = atd.adrelid
  AND ad.attnum = atd.adnum
  AND d.classid = 'pg_attrdef'::REGCLASS::OID
  AND d.refclassid = 'pg_class'::REGCLASS::OID
  AND d.objid = atd.oid
  AND d.refobjid = ac.attrelid
  AND d.refobjsubid = ac.attnum
  AND ad.attgenerated <> ''::"char"
  AND PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT);

ALTER TABLE column_column_usage
    OWNER TO kiwi;

GRANT SELECT ON column_column_usage TO PUBLIC;

