CREATE VIEW foreign_server_options (foreign_server_catalog, foreign_server_name, option_name, option_value) AS
SELECT foreign_server_catalog,
       foreign_server_name,
       (PG_OPTIONS_TO_TABLE(srvoptions)).option_name::information_schema.SQL_IDENTIFIER  AS option_name,
       (PG_OPTIONS_TO_TABLE(srvoptions)).option_value::information_schema.CHARACTER_DATA AS option_value
FROM information_schema._pg_foreign_servers s;

ALTER TABLE foreign_server_options
    OWNER TO kiwi;

GRANT SELECT ON foreign_server_options TO PUBLIC;

