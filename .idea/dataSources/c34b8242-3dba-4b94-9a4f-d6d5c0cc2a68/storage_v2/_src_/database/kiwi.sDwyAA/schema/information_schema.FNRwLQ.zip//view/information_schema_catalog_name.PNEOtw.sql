CREATE VIEW information_schema_catalog_name(catalog_name) AS
SELECT CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS catalog_name;

ALTER TABLE information_schema_catalog_name
    OWNER TO kiwi;

GRANT SELECT ON information_schema_catalog_name TO PUBLIC;

