CREATE VIEW role_udt_grants (grantor, grantee, udt_catalog, udt_schema, udt_name, privilege_type, is_grantable) AS
SELECT grantor,
       grantee,
       udt_catalog,
       udt_schema,
       udt_name,
       privilege_type,
       is_grantable
FROM information_schema.udt_privileges
WHERE (grantor::NAME IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles))
   OR (grantee::NAME IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles));

ALTER TABLE role_udt_grants
    OWNER TO kiwi;

GRANT SELECT ON role_udt_grants TO PUBLIC;

