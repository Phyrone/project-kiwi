CREATE VIEW table_privileges
            (grantor, grantee, table_catalog, table_schema, table_name, privilege_type, is_grantable, with_hierarchy) AS
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER  AS grantor,
       grantee.rolname::information_schema.SQL_IDENTIFIER    AS grantee,
       CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER AS table_catalog,
       nc.nspname::information_schema.SQL_IDENTIFIER         AS table_schema,
       c.relname::information_schema.SQL_IDENTIFIER          AS table_name,
       c.prtype::information_schema.CHARACTER_DATA           AS privilege_type,
       CASE
           WHEN PG_HAS_ROLE(grantee.oid, c.relowner, 'USAGE'::TEXT) OR c.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.YES_OR_NO                 AS is_grantable,
       CASE
           WHEN c.prtype = 'SELECT'::TEXT THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.YES_OR_NO                 AS with_hierarchy
FROM (SELECT pg_class.oid,
             pg_class.relname,
             pg_class.relnamespace,
             pg_class.relkind,
             pg_class.relowner,
             (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor        AS grantor,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).grantee                         AS grantee,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).privilege_type                  AS privilege_type,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).is_grantable                    AS is_grantable
      FROM pg_class) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
     pg_namespace nc,
     pg_authid u_grantor,
     (SELECT pg_authid.oid,
             pg_authid.rolname
      FROM pg_authid
      UNION ALL
      SELECT 0::OID AS oid,
             'PUBLIC'::NAME) grantee(oid, rolname)
WHERE c.relnamespace = nc.oid
  AND (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  AND c.grantee = grantee.oid
  AND c.grantor = u_grantor.oid
  AND (c.prtype = ANY
       (ARRAY ['INSERT'::TEXT, 'SELECT'::TEXT, 'UPDATE'::TEXT, 'DELETE'::TEXT, 'TRUNCATE'::TEXT, 'REFERENCES'::TEXT, 'TRIGGER'::TEXT]))
  AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
       grantee.rolname = 'PUBLIC'::NAME);

ALTER TABLE table_privileges
    OWNER TO kiwi;

GRANT SELECT ON table_privileges TO PUBLIC;

