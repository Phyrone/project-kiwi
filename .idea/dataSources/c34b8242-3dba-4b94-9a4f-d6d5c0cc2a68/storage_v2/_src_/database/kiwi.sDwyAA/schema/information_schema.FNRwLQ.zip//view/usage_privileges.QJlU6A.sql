CREATE VIEW usage_privileges
            (grantor, grantee, object_catalog, object_schema, object_name, object_type, privilege_type, is_grantable) AS
SELECT u.rolname::information_schema.SQL_IDENTIFIER                      AS grantor,
       'PUBLIC'::NAME::information_schema.SQL_IDENTIFIER                 AS grantee,
       CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER             AS object_catalog,
       n.nspname::information_schema.SQL_IDENTIFIER                      AS object_schema,
       c.collname::information_schema.SQL_IDENTIFIER                     AS object_name,
       'COLLATION'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS object_type,
       'USAGE'::CHARACTER VARYING::information_schema.CHARACTER_DATA     AS privilege_type,
       'NO'::CHARACTER VARYING::information_schema.YES_OR_NO             AS is_grantable
FROM pg_authid u,
     pg_namespace n,
     pg_collation c
WHERE u.oid = c.collowner
  AND c.collnamespace = n.oid
  AND (c.collencoding = ANY (ARRAY ['-1'::INTEGER, (SELECT pg_database.encoding
                                                    FROM pg_database
                                                    WHERE pg_database.datname = CURRENT_DATABASE())]))
UNION ALL
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER           AS grantor,
       grantee.rolname::information_schema.SQL_IDENTIFIER             AS grantee,
       CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER          AS object_catalog,
       n.nspname::information_schema.SQL_IDENTIFIER                   AS object_schema,
       t.typname::information_schema.SQL_IDENTIFIER                   AS object_name,
       'DOMAIN'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS object_type,
       'USAGE'::CHARACTER VARYING::information_schema.CHARACTER_DATA  AS privilege_type,
       CASE
           WHEN PG_HAS_ROLE(grantee.oid, t.typowner, 'USAGE'::TEXT) OR t.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.YES_OR_NO                          AS is_grantable
FROM (SELECT pg_type.oid,
             pg_type.typname,
             pg_type.typnamespace,
             pg_type.typtype,
             pg_type.typowner,
             (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor        AS grantor,
             (aclexplode(COALESCE(pg_type.typacl,
                                  acldefault('T'::"char", pg_type.typowner)))).grantee                        AS grantee,
             (aclexplode(COALESCE(pg_type.typacl,
                                  acldefault('T'::"char", pg_type.typowner)))).privilege_type                 AS privilege_type,
             (aclexplode(COALESCE(pg_type.typacl,
                                  acldefault('T'::"char", pg_type.typowner)))).is_grantable                   AS is_grantable
      FROM pg_type) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable),
     pg_namespace n,
     pg_authid u_grantor,
     (SELECT pg_authid.oid,
             pg_authid.rolname
      FROM pg_authid
      UNION ALL
      SELECT 0::OID AS oid,
             'PUBLIC'::NAME) grantee(oid, rolname)
WHERE t.typnamespace = n.oid
  AND t.typtype = 'd'::"char"
  AND t.grantee = grantee.oid
  AND t.grantor = u_grantor.oid
  AND t.prtype = 'USAGE'::TEXT
  AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
       grantee.rolname = 'PUBLIC'::NAME)
UNION ALL
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER                         AS grantor,
       grantee.rolname::information_schema.SQL_IDENTIFIER                           AS grantee,
       CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                        AS object_catalog,
       ''::NAME::information_schema.SQL_IDENTIFIER                                  AS object_schema,
       fdw.fdwname::information_schema.SQL_IDENTIFIER                               AS object_name,
       'FOREIGN DATA WRAPPER'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS object_type,
       'USAGE'::CHARACTER VARYING::information_schema.CHARACTER_DATA                AS privilege_type,
       CASE
           WHEN PG_HAS_ROLE(grantee.oid, fdw.fdwowner, 'USAGE'::TEXT) OR fdw.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.YES_OR_NO                                        AS is_grantable
FROM (SELECT pg_foreign_data_wrapper.fdwname,
             pg_foreign_data_wrapper.fdwowner,
             (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl,
                                  acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).grantor        AS grantor,
             (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl,
                                  acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).grantee        AS grantee,
             (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl,
                                  acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).privilege_type AS privilege_type,
             (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl,
                                  acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).is_grantable   AS is_grantable
      FROM pg_foreign_data_wrapper) fdw(fdwname, fdwowner, grantor, grantee, prtype, grantable),
     pg_authid u_grantor,
     (SELECT pg_authid.oid,
             pg_authid.rolname
      FROM pg_authid
      UNION ALL
      SELECT 0::OID AS oid,
             'PUBLIC'::NAME) grantee(oid, rolname)
WHERE u_grantor.oid = fdw.grantor
  AND grantee.oid = fdw.grantee
  AND fdw.prtype = 'USAGE'::TEXT
  AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
       grantee.rolname = 'PUBLIC'::NAME)
UNION ALL
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER                   AS grantor,
       grantee.rolname::information_schema.SQL_IDENTIFIER                     AS grantee,
       CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER                  AS object_catalog,
       ''::NAME::information_schema.SQL_IDENTIFIER                            AS object_schema,
       srv.srvname::information_schema.SQL_IDENTIFIER                         AS object_name,
       'FOREIGN SERVER'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS object_type,
       'USAGE'::CHARACTER VARYING::information_schema.CHARACTER_DATA          AS privilege_type,
       CASE
           WHEN PG_HAS_ROLE(grantee.oid, srv.srvowner, 'USAGE'::TEXT) OR srv.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.YES_OR_NO                                  AS is_grantable
FROM (SELECT pg_foreign_server.srvname,
             pg_foreign_server.srvowner,
             (aclexplode(COALESCE(pg_foreign_server.srvacl,
                                  acldefault('S'::"char", pg_foreign_server.srvowner)))).grantor        AS grantor,
             (aclexplode(COALESCE(pg_foreign_server.srvacl,
                                  acldefault('S'::"char", pg_foreign_server.srvowner)))).grantee        AS grantee,
             (aclexplode(COALESCE(pg_foreign_server.srvacl,
                                  acldefault('S'::"char", pg_foreign_server.srvowner)))).privilege_type AS privilege_type,
             (aclexplode(COALESCE(pg_foreign_server.srvacl,
                                  acldefault('S'::"char", pg_foreign_server.srvowner)))).is_grantable   AS is_grantable
      FROM pg_foreign_server) srv(srvname, srvowner, grantor, grantee, prtype, grantable),
     pg_authid u_grantor,
     (SELECT pg_authid.oid,
             pg_authid.rolname
      FROM pg_authid
      UNION ALL
      SELECT 0::OID AS oid,
             'PUBLIC'::NAME) grantee(oid, rolname)
WHERE u_grantor.oid = srv.grantor
  AND grantee.oid = srv.grantee
  AND srv.prtype = 'USAGE'::TEXT
  AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
       grantee.rolname = 'PUBLIC'::NAME)
UNION ALL
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER             AS grantor,
       grantee.rolname::information_schema.SQL_IDENTIFIER               AS grantee,
       CURRENT_DATABASE()::information_schema.SQL_IDENTIFIER            AS object_catalog,
       n.nspname::information_schema.SQL_IDENTIFIER                     AS object_schema,
       c.relname::information_schema.SQL_IDENTIFIER                     AS object_name,
       'SEQUENCE'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS object_type,
       'USAGE'::CHARACTER VARYING::information_schema.CHARACTER_DATA    AS privilege_type,
       CASE
           WHEN PG_HAS_ROLE(grantee.oid, c.relowner, 'USAGE'::TEXT) OR c.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
           END::information_schema.YES_OR_NO                            AS is_grantable
FROM (SELECT pg_class.oid,
             pg_class.relname,
             pg_class.relnamespace,
             pg_class.relkind,
             pg_class.relowner,
             (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor        AS grantor,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).grantee                         AS grantee,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).privilege_type                  AS privilege_type,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).is_grantable                    AS is_grantable
      FROM pg_class) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
     pg_namespace n,
     pg_authid u_grantor,
     (SELECT pg_authid.oid,
             pg_authid.rolname
      FROM pg_authid
      UNION ALL
      SELECT 0::OID AS oid,
             'PUBLIC'::NAME) grantee(oid, rolname)
WHERE c.relnamespace = n.oid
  AND c.relkind = 'S'::"char"
  AND c.grantee = grantee.oid
  AND c.grantor = u_grantor.oid
  AND c.prtype = 'USAGE'::TEXT
  AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
       grantee.rolname = 'PUBLIC'::NAME);

ALTER TABLE usage_privileges
    OWNER TO kiwi;

GRANT SELECT ON usage_privileges TO PUBLIC;

