CREATE VIEW user_mapping_options
            (authorization_identifier, foreign_server_catalog, foreign_server_name, option_name, option_value) AS
SELECT um.authorization_identifier,
       um.foreign_server_catalog,
       um.foreign_server_name,
       opts.option_name::information_schema.SQL_IDENTIFIER AS option_name,
       CASE
           WHEN um.umuser <> 0::OID AND um.authorization_identifier::NAME = CURRENT_USER OR
                um.umuser = 0::OID AND PG_HAS_ROLE(um.srvowner::NAME, 'USAGE'::TEXT) OR (SELECT pg_authid.rolsuper
                                                                                         FROM pg_authid
                                                                                         WHERE pg_authid.rolname = CURRENT_USER)
               THEN opts.option_value
           ELSE NULL::TEXT
           END::information_schema.CHARACTER_DATA          AS option_value
FROM information_schema._pg_user_mappings um,
     LATERAL PG_OPTIONS_TO_TABLE(um.umoptions) opts(option_name, option_value);

ALTER TABLE user_mapping_options
    OWNER TO kiwi;

GRANT SELECT ON user_mapping_options TO PUBLIC;

