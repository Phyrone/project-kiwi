CREATE FUNCTION date_part(text, date) RETURNS double precision
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN date_part($1, ($2)::timestamp without time zone);

COMMENT ON FUNCTION date_part(TEXT, DATE) IS 'extract field from date';

ALTER FUNCTION date_part(TEXT, DATE) OWNER TO kiwi;

