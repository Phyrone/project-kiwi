CREATE FUNCTION interval_pl_timestamptz(interval, timestamp with time zone) RETURNS timestamp with time zone
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN ($2 + $1);

COMMENT ON FUNCTION interval_pl_timestamptz(INTERVAL, TIMESTAMP WITH TIME ZONE) IS 'implementation of + operator';

ALTER FUNCTION interval_pl_timestamptz(INTERVAL, TIMESTAMP WITH TIME ZONE) OWNER TO kiwi;

