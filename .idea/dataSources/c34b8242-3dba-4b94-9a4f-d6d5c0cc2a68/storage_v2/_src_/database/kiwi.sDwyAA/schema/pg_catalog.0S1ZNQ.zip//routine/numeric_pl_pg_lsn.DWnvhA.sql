CREATE FUNCTION numeric_pl_pg_lsn(numeric, pg_lsn) RETURNS pg_lsn
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN ($2 + $1);

COMMENT ON FUNCTION numeric_pl_pg_lsn(NUMERIC, PG_LSN) IS 'implementation of + operator';

ALTER FUNCTION numeric_pl_pg_lsn(NUMERIC, PG_LSN) OWNER TO kiwi;

