CREATE FUNCTION obj_description(oid) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
BEGIN ATOMIC
 SELECT pg_description.description
    FROM pg_description
   WHERE ((pg_description.objoid = $1) AND (pg_description.objsubid = 0));
END;

COMMENT ON FUNCTION obj_description(OID) IS 'deprecated, use two-argument form instead';

ALTER FUNCTION obj_description(OID) OWNER TO kiwi;

