CREATE FUNCTION "overlaps"(timestamp without time zone, timestamp without time zone, timestamp without time zone, interval) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN (($1, $2) OVERLAPS ($3, ($3 + $4)));

COMMENT ON FUNCTION "overlaps"(TIMESTAMP, TIMESTAMP, TIMESTAMP, INTERVAL) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIMESTAMP, TIMESTAMP, TIMESTAMP, INTERVAL) OWNER TO kiwi;

