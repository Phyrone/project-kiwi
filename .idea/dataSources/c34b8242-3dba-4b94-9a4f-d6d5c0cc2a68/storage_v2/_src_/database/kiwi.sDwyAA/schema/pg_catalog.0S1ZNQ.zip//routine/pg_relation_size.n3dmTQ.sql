CREATE FUNCTION pg_relation_size(regclass) RETURNS bigint
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN pg_relation_size($1, 'main'::text);

COMMENT ON FUNCTION pg_relation_size(REGCLASS) IS 'disk space usage for the main fork of the specified table or index';

ALTER FUNCTION pg_relation_size(REGCLASS) OWNER TO kiwi;

