CREATE FUNCTION rpad(text, integer) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN rpad($1, $2, ' '::text);

COMMENT ON FUNCTION rpad(TEXT, INTEGER) IS 'right-pad string to length';

ALTER FUNCTION rpad(TEXT, INTEGER) OWNER TO kiwi;

