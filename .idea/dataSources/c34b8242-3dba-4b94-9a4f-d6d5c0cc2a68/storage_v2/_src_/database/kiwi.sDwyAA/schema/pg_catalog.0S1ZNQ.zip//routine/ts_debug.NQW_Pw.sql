CREATE FUNCTION ts_debug(config regconfig, document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) RETURNS SETOF record
    STABLE
    STRICT
    PARALLEL SAFE
    LANGUAGE sql
BEGIN ATOMIC
 SELECT tt.alias,
     tt.description,
     parse.token,
     ARRAY( SELECT (m.mapdict)::regdictionary AS mapdict
            FROM pg_ts_config_map m
           WHERE ((m.mapcfg = (ts_debug.config)::oid) AND (m.maptokentype = parse.tokid))
           ORDER BY m.mapseqno) AS dictionaries,
     ( SELECT (m.mapdict)::regdictionary AS mapdict
            FROM pg_ts_config_map m
           WHERE ((m.mapcfg = (ts_debug.config)::oid) AND (m.maptokentype = parse.tokid))
           ORDER BY (ts_lexize((m.mapdict)::regdictionary, parse.token) IS NULL), m.mapseqno
          LIMIT 1) AS dictionary,
     ( SELECT ts_lexize((m.mapdict)::regdictionary, parse.token) AS ts_lexize
            FROM pg_ts_config_map m
           WHERE ((m.mapcfg = (ts_debug.config)::oid) AND (m.maptokentype = parse.tokid))
           ORDER BY (ts_lexize((m.mapdict)::regdictionary, parse.token) IS NULL), m.mapseqno
          LIMIT 1) AS lexemes
    FROM ts_parse(( SELECT pg_ts_config.cfgparser
            FROM pg_ts_config
           WHERE (pg_ts_config.oid = (ts_debug.config)::oid)), ts_debug.document) parse(tokid, token),
     ts_token_type(( SELECT pg_ts_config.cfgparser
            FROM pg_ts_config
           WHERE (pg_ts_config.oid = (ts_debug.config)::oid))) tt(tokid, alias, description)
   WHERE (tt.tokid = parse.tokid);
END;

COMMENT ON FUNCTION ts_debug(REGCONFIG, TEXT, OUT TEXT, OUT TEXT, OUT TEXT, OUT REGDICTIONARY[], OUT REGDICTIONARY, OUT TEXT[]) IS 'debug function for text search configuration';

ALTER FUNCTION ts_debug(REGCONFIG, TEXT, OUT TEXT, OUT TEXT, OUT TEXT, OUT REGDICTIONARY[], OUT REGDICTIONARY, OUT TEXT[]) OWNER TO kiwi;

