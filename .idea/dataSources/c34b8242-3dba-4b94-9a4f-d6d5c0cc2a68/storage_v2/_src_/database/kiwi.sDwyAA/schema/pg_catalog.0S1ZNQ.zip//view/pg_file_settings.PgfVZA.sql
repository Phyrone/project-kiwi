CREATE VIEW pg_file_settings(sourcefile, sourceline, seqno, name, setting, applied, error) AS
SELECT sourcefile,
       sourceline,
       seqno,
       name,
       setting,
       applied,
       error
FROM pg_show_all_file_settings() a(sourcefile, sourceline, seqno, name, setting, applied, error);

ALTER TABLE pg_file_settings
    OWNER TO kiwi;

