CREATE VIEW pg_stat_progress_basebackup
            (pid, phase, backup_total, backup_streamed, tablespaces_total, tablespaces_streamed) AS
SELECT pid,
       CASE param1
           WHEN 0 THEN 'initializing'::TEXT
           WHEN 1 THEN 'waiting for checkpoint to finish'::TEXT
           WHEN 2 THEN 'estimating backup size'::TEXT
           WHEN 3 THEN 'streaming database files'::TEXT
           WHEN 4 THEN 'waiting for wal archiving to finish'::TEXT
           WHEN 5 THEN 'transferring wal files'::TEXT
           ELSE NULL::TEXT
           END AS phase,
       CASE param2
           WHEN '-1'::INTEGER THEN NULL::BIGINT
           ELSE param2
           END AS backup_total,
       param3  AS backup_streamed,
       param4  AS tablespaces_total,
       param5  AS tablespaces_streamed
FROM pg_stat_get_progress_info('BASEBACKUP'::TEXT) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                     param7, param8, param9, param10, param11, param12, param13,
                                                     param14, param15, param16, param17, param18, param19, param20);

ALTER TABLE pg_stat_progress_basebackup
    OWNER TO kiwi;

GRANT SELECT ON pg_stat_progress_basebackup TO PUBLIC;

