CREATE VIEW pg_stat_slru
            (name, blks_zeroed, blks_hit, blks_read, blks_written, blks_exists, flushes, truncates, stats_reset) AS
SELECT name,
       blks_zeroed,
       blks_hit,
       blks_read,
       blks_written,
       blks_exists,
       flushes,
       truncates,
       stats_reset
FROM pg_stat_get_slru() s(name, blks_zeroed, blks_hit, blks_read, blks_written, blks_exists, flushes, truncates,
                          stats_reset);

ALTER TABLE pg_stat_slru
    OWNER TO kiwi;

GRANT SELECT ON pg_stat_slru TO PUBLIC;

