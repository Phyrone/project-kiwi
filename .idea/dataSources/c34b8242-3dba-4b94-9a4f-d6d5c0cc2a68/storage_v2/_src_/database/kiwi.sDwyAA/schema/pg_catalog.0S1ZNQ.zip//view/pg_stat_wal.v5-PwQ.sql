CREATE VIEW pg_stat_wal
            (wal_records, wal_fpi, wal_bytes, wal_buffers_full, wal_write, wal_sync, wal_write_time, wal_sync_time,
             stats_reset) AS
SELECT wal_records,
       wal_fpi,
       wal_bytes,
       wal_buffers_full,
       wal_write,
       wal_sync,
       wal_write_time,
       wal_sync_time,
       stats_reset
FROM pg_stat_get_wal() w(wal_records, wal_fpi, wal_bytes, wal_buffers_full, wal_write, wal_sync, wal_write_time,
                         wal_sync_time, stats_reset);

ALTER TABLE pg_stat_wal
    OWNER TO kiwi;

GRANT SELECT ON pg_stat_wal TO PUBLIC;

