CREATE VIEW pg_statio_user_sequences(relid, schemaname, relname, blks_read, blks_hit) AS
SELECT relid,
       schemaname,
       relname,
       blks_read,
       blks_hit
FROM pg_statio_all_sequences
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::NAME, 'information_schema'::NAME]))
  AND schemaname !~ '^pg_toast'::TEXT;

ALTER TABLE pg_statio_user_sequences
    OWNER TO kiwi;

GRANT SELECT ON pg_statio_user_sequences TO PUBLIC;

