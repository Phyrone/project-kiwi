CREATE VIEW pg_timezone_abbrevs(abbrev, utc_offset, is_dst) AS
SELECT abbrev,
       utc_offset,
       is_dst
FROM pg_timezone_abbrevs() pg_timezone_abbrevs(abbrev, utc_offset, is_dst);

ALTER TABLE pg_timezone_abbrevs
    OWNER TO kiwi;

GRANT SELECT ON pg_timezone_abbrevs TO PUBLIC;

