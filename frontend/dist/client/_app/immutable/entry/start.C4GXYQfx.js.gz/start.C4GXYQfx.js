import{a as t}from"../chunks/entry.CNWT8fPr.js";export{t as start};
